# Copyright 2023 VMware, Inc.
# All rights reserved. -- VMware Confidential

""" Define system-storage exceptions"""
class SystemStorageException(Exception):
   msg = ''
   stackTrace = ''
   def __init__(self, *args):
      self.msg = args[0]
      if len(args) == 2:
         self.stackTrace = args[1]

class UpgradeBackupError(SystemStorageException):
   """Raised when failed to backup files from the VFAT partitions to Ramdisk."""
   pass

