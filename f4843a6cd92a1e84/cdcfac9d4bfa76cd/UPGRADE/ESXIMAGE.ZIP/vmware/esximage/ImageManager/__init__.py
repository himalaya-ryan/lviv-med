# esximage.ImageManager module
